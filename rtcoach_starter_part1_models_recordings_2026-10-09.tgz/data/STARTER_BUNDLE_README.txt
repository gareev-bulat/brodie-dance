Brodie FaceTime coach: starter bundle (2026-10-09, branch claude/brodie-rt-coach-handoff-rv27m3)

Three parts (each under the 30 MB chat limit); unpack all three at the root of your checkout, everything lands under
data/, which git ignores:
  tar xzf rtcoach_starter_part1_models_recordings_2026-10-09.tgz
  tar xzf rtcoach_starter_part2_bank_au_2026-10-09.tgz
  tar xzf rtcoach_starter_part3_bank_puck_2026-10-09.tgz Then read docs/STARTER_README.md (setup, line rules, latency, licence) and docs/STARTER_EVENTS.md
(the event schema and the worker's run modes).

Contents
  data/models/clf_pose.pt            pose classifier (exercise + fault heads), loaded by the perception pipeline
  data/models/trigger_lr.json        learned correction trigger (numpy only); without it the coach falls back to a rule
  data/cues_audio_gemini_au/         the voice bank the coach prefers: 378 clips, Gemini TTS, voice Puck with an
                                     Australian trainer direction, 24 kHz mono PCM, manifest.json keyed on the string
  data/cues_audio_gemini/            the same strings in plain Puck (fallback bank, 379 clips)
  data/tmp/mac_handoff/crops/        James's own recordings (with his consent), cropped to the camera view the coach
                                     sees (portrait, 10 fps): run3 (clean full plan, LiveKit phone page), run2 (end of
                                     squats, pushups with phone handling, jacks, lunges), live (full plan on a real
                                     FaceTime call); <name>.events.jsonl is each one's schema v1 event log from
                                     `python -m facetime.replay_local --video <crop> --plan "squats:10,pushups:8,jumping jacks:20,lunges:10" --fast --events ...`
  data/tmp/mac_handoff/segments/     per-exercise cuts of the same recordings

Licence: clf_pose.pt and trigger_lr.json are results of a 30-day QEVD evaluation licence (docs/STARTER_README.md
section 9): private, never on a public URL, no participant identification. No QEVD clips, frames or annotations are in
this bundle. The recordings are James's; do not publish them. The audio bank wording is Brodie's.
